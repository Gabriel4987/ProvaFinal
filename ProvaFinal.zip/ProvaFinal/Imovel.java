package ProvaFinal;


public class Imovel {
    
    private String nome;
    private String descr;
    private String categoria;
    private String tipo;
    private String valor;

    public Imovel() {
    }

        
    public Imovel(String nome, String descr, String categoria, String tipo, String valor) {
        this.nome = nome;
        this.descr = descr;
        this.categoria = categoria;
        this.tipo = tipo;
        this.valor = valor;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
    
    
}
