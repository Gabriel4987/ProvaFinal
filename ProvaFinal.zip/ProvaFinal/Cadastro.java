package ProvaFinal;

import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.table.DefaultTableModel;

public class Cadastro extends javax.swing.JFrame {

    
    java.util.List<Imovel> lista = new ArrayList<>();
    
    public Cadastro() {
        initComponents();
        configs();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        tabCadastrar = new javax.swing.JPanel();
        labelNome = new javax.swing.JLabel();
        textoNome = new javax.swing.JTextField();
        labelCategoria = new javax.swing.JLabel();
        labelTipo = new javax.swing.JLabel();
        labelValor = new javax.swing.JLabel();
        textoValor = new javax.swing.JTextField();
        buttonSalvar = new javax.swing.JButton();
        labelDescricao = new javax.swing.JLabel();
        textoDescricao = new javax.swing.JTextArea();
        buttonLimp = new javax.swing.JButton();
        tbpUnico = new javax.swing.JTabbedPane();
        scpPainel = new javax.swing.JScrollPane();
        rdbResidencial = new javax.swing.JRadioButton();
        rdbComercial = new javax.swing.JRadioButton();
        cbbTipo = new javax.swing.JComboBox<>();
        scpTabImoveis = new javax.swing.JScrollPane();
        tabImoveis = new javax.swing.JTable();

        buttonLimp.setText("Limpar");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labelNome.setFont(new java.awt.Font("DialogInput", 0, 18)); // NOI18N
        labelNome.setText("Nome:");

        labelDescricao.setFont(new java.awt.Font("DialogInput", 0, 18)); // NOI18N
        labelDescricao.setText("Descrição:");

        textoDescricao.setColumns(20);
        textoDescricao.setRows(5);
        scpPainel.setViewportView(textoDescricao);

        labelCategoria.setFont(new java.awt.Font("DialogInput", 0, 18)); // NOI18N
        labelCategoria.setText("Categoria:");

        rdbResidencial.setText("Residencial");

        rdbComercial.setText("Comercial");

        labelTipo.setFont(new java.awt.Font("DialogInput", 0, 18)); // NOI18N
        labelTipo.setText("Tipo:");

        cbbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Apartamento", "Casa", "Chácara", "Sala", "Salão", "Sítio" }));

        labelValor.setFont(new java.awt.Font("DialogInput", 0, 18)); // NOI18N
        labelValor.setText("Valor:");

        buttonSalvar.setText("Salvar");
        buttonSalvar.setMaximumSize(new java.awt.Dimension(70, 32));
        buttonSalvar.setMinimumSize(new java.awt.Dimension(70, 32));
        buttonSalvar.setPreferredSize(new java.awt.Dimension(70, 32));
        buttonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        tabImoveis.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        scpTabImoveis.setViewportView(tabImoveis);

        javax.swing.GroupLayout tabCadastrarLayout = new javax.swing.GroupLayout(tabCadastrar);
        tabCadastrar.setLayout(tabCadastrarLayout);
        tabCadastrarLayout.setHorizontalGroup(
            tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabCadastrarLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabCadastrarLayout.createSequentialGroup()
                        .addComponent(labelNome)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textoNome, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabCadastrarLayout.createSequentialGroup()
                        .addGroup(tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(tabCadastrarLayout.createSequentialGroup()
                                .addComponent(labelCategoria)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rdbResidencial))
                            .addGroup(tabCadastrarLayout.createSequentialGroup()
                                .addComponent(labelTipo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(tabCadastrarLayout.createSequentialGroup()
                                .addComponent(labelValor)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textoValor, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(buttonSalvar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(rdbComercial, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(tabCadastrarLayout.createSequentialGroup()
                        .addComponent(labelDescricao)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(scpPainel, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scpTabImoveis, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
                .addContainerGap())
        );
        tabCadastrarLayout.setVerticalGroup(
            tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabCadastrarLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNome)
                    .addComponent(textoNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(tabCadastrarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scpTabImoveis, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addGap(18, 18, 18))
            .addGroup(tabCadastrarLayout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelCategoria)
                    .addComponent(rdbResidencial)
                    .addComponent(rdbComercial))
                .addGroup(tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabCadastrarLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelTipo)
                            .addComponent(cbbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelValor)
                            .addComponent(textoValor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tabCadastrarLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(buttonSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)))
                .addGroup(tabCadastrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(scpPainel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6))
        );

        tbpUnico.addTab("Cadastrar", tabCadastrar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(tbpUnico, javax.swing.GroupLayout.PREFERRED_SIZE, 758, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tbpUnico, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        Imovel imovel = new Imovel();

        imovel.setNome(textoNome.getText());
        imovel.setDescr(textoDescricao.getText());

        String _t = (String) cbbTipo.getSelectedItem();
        imovel.setTipo(_t);

        String _c = "";
        if (rdbComercial.isSelected()){
            _c = "Comercial";
        }else if (rdbResidencial.isSelected()){
            _c = "Residencial";
        }
        imovel.setCategoria(_c);

        imovel.setValor(textoValor.getText());

        lista.add(imovel);

        DefaultTableModel u = (DefaultTableModel)tabImoveis.getModel();
        u.addRow(new String[]{imovel.getNome(), imovel.getCategoria(), imovel.getTipo(), imovel.getValor(), imovel.getDescr()});
        tabImoveis.setModel(u);

    }//GEN-LAST:event_btnSalvarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonLimp;
    private javax.swing.JButton buttonSalvar;
    private javax.swing.JComboBox<String> cbbTipo;
    private javax.swing.JLabel labelCategoria;
    private javax.swing.JLabel labelDescricao;
    private javax.swing.JLabel labelNome;
    private javax.swing.JLabel labelTipo;
    private javax.swing.JLabel labelValor;
    private javax.swing.JRadioButton rdbComercial;
    private javax.swing.JRadioButton rdbResidencial;
    private javax.swing.JScrollPane scpPainel;
    private javax.swing.JScrollPane scpTabImoveis;
    private javax.swing.JPanel tabCadastrar;
    private javax.swing.JTable tabImoveis;
    private javax.swing.JTabbedPane tbpUnico;
    private javax.swing.JTextArea textoDescricao;
    private javax.swing.JTextField textoNome;
    private javax.swing.JTextField textoValor;
    // End of variables declaration//GEN-END:variables

    private void configs() {       
        this.setTitle("Cadastro de Imóveis");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        
        //Definir a seleção do RadioButton (RDB) como mutuamente exclusiva
        ButtonGroup bg = new ButtonGroup();
        bg.add(rdbComercial);
        bg.add(rdbResidencial);
        
        table();
    }
    
    private void table(){
        DefaultTableModel u = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }  
        };
        
        //Definir as colunas
        u.addColumn("Nome");
        u.addColumn("Categoria");
        u.addColumn("Tipo");
        u.addColumn("Valor");
        u.addColumn("Descrição");
        tabImoveis.setModel(u);
        
    }
}